public class Main {
  public static void main(String[] args) {
    HelloWorld.hello();
    HelloWorld.getMessage("Hello");
  }
}
