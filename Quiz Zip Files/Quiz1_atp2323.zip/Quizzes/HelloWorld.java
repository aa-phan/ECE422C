public class HelloWorld {
  public static void hello() {
    System.out.println("Hello, world!");
  }

  public static void getMessage(String a) {
    System.out.println(a);
  }
}
