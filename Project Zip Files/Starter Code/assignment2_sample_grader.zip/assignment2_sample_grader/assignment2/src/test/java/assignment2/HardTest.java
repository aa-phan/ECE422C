package assignment2;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.rules.Timeout;

import scoreannotation.Score;
import testutils.NoExitSecurityManager;
import static testutils.Statics.getStringFromResource;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;

public class HardTest {
    private SecurityManager initialSecurityManager = System.getSecurityManager();
    private InputStream stdIn = System.in;
    private PrintStream stdOut = System.out;

    @Rule
    public Timeout globalTimeout = Timeout.seconds(2);

    @After
    public void teardown() {
        System.setOut(stdOut);
        System.setIn(stdIn);
        System.setSecurityManager(initialSecurityManager);
    }

    // private void test(String testName, String gradingWord, GameConfiguration config) {
    //     /* SETUP */
    //     // Disallow System.exit() with a SecurityManager
    //     System.setSecurityManager(new NoExitSecurityManager());

    //     // Replace stdin
    //     // String input = getStringFromResource(
    //     //         getClass(),
    //     //         testName + "/input.txt"
    //     // );
    //     String input = "y\nawake\n[history]\nheard\n[history]\nalgae\nn\n";
    //     System.setIn(new ByteArrayInputStream(input.getBytes()));

    //     // Replace stdout
    //     PrintStream stdout = System.out;
    //     ByteArrayOutputStream output = new ByteArrayOutputStream();
    //     System.setOut(new PrintStream(output));

    //     /* EXECUTE UNIT UNDER TEST */
    //     Dictionary.gradingWord = gradingWord;
    //     Driver driver = new Driver();
    //     GameConfiguration c = new GameConfiguration(5, 6, false);
    //     driver.start(c);

    //     /* VERIFICATION */
    //     // String expected = getStringFromResource(
    //     //         getClass(),
    //     //         testName + "/expected_output.txt"
    //     // );
    //     // String expected = "Hello! Welcome to Wordle.\nDo you want to play a new game? (y/n)\nEnter your guess: \nGGGGG\nDo you want to play a new game? (y/n)";
    //     // assertEquals(expected.replaceAll("\\s+", " "), output.toString().replaceAll("\\s+"," "));
    //     // assertTrue(genMock.isDone());
    //     System.setOut(stdout);

    //     // assertEqualsWordle(output.toString(), output.toString());
    //     System.out.println("raw output:");
    //     System.out.println(output.toString());
    //     System.out.println("processed output:");
    //     System.out.println(processString(output.toString()));
    //     // System.out.println(output.toString().replaceAll("\\s+", " "));
    //     assertTrue(true);
    // }

    public String processString(String input){
        String[] lines = input.split("\n");
        String output = "";
        for (String line: lines){
            if (line.startsWith("Green:") || line.startsWith("Yellow:") || line.startsWith("Absent:") || line.startsWith("Unused:")){
                int idx = line.indexOf(':');
                String chars = line.substring(idx+1, line.length());
                char[] ac = chars.toCharArray();
                Arrays.sort(ac);
                chars = new String(ac).replaceAll(" ", "").replaceAll(",", "");
                output+= line.substring(0, idx+1) + chars+"\n";
            }
            else{
                output+=line+"\n";
            }
        }
        return output.replaceAll("\\s+", " ");
    }

    public void assertEqualsWordle(String expected, String output){
        expected = processString(expected);
        output = processString(output);
        if(!expected.equals(output)){
            System.out.println("========================");
            System.out.println("EXPECTED OUTPUT: ");
            System.out.println(expected);
            System.out.println("========================");
            System.out.println("YOUR OUTPUT: ");
            System.out.println(output);
            System.out.println("========================");
        }
        assertEquals(expected, output);
    }

    // @Test
    // @Score(1)
    // public void testAccordingToProjectDescription() {
    //     test("", "algae", null);
    // }

    private void test(int num) {
        /* SETUP */
        // Disallow System.exit() with a SecurityManager
        System.setSecurityManager(new NoExitSecurityManager());

        String meta = getStringFromResource(
                getClass(), "hardtest_"+num +"/meta_data.txt"
        );
        // System.out.println("Meta: "+ meta);
        int length = Integer.parseInt(meta.split(" ")[0]);
        int nGuesses = Integer.parseInt(meta.split(" ")[1]);

        // Replace stdin
        // String input = getStringFromResource(
        //         getClass(),
        //         testName + "/input.txt"
        // );
        String input = getStringFromResource(
                getClass(), "hardtest_"+num +"/input.txt"
        );
        // System.out.println("Input: "+ input);

        // String input = "y\nawake\n[history]\nheard\n[history]\nalgae\nn\n";
        // input = "y\nawake\n[history]\nheard\n[history]\nalgae\nn\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        // Replace stdout
        PrintStream stdout = System.out;
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output));

        String sw = getStringFromResource(
                getClass(), "hardtest_"+num +"/secret_words.txt"
        );
        // System.out.println("SW: "+ sw);
        String[] secret_words = sw.split(" ");

        // System.out.println("DONE DONE DONE");

        /* EXECUTE UNIT UNDER TEST */
        // Dictionary.gradingWord = "algae";
        Dictionary.gradingWords = secret_words;
        Dictionary.wordIndex = 0;
        Driver driver = new Driver();
        GameConfiguration c = new GameConfiguration(length, nGuesses, false);
        driver.start_hardmode(c);

        System.setOut(stdout);

        /* VERIFICATION */
        String expected = getStringFromResource(
                getClass(), "hardtest_"+num +"/output.txt"
        );
        // System.out.println("Expected: "+expected);
        // String expected = "Hello! Welcome to Wordle.\nDo you want to play a new game? (y/n)\nEnter your guess: \nGGGGG\nDo you want to play a new game? (y/n)";
        // assertEquals(expected.replaceAll("\\s+", " "), output.toString().replaceAll("\\s+"," "));
        // assertTrue(genMock.isDone());

        assertEqualsWordle(expected, output.toString());
        // System.out.println("raw output:");
        // System.out.println(output.toString());
        // System.out.println("processed output:");
        // System.out.println(processString(output.toString()));
        // System.out.println(output.toString().replaceAll("\\s+", " "));
        assertTrue(true);
    }

    @Test(timeout = 100)
    @Score(1)
    public void testRun1() {
        test(1);
    }
}
